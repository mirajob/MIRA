# MIRA — Brand Package v1.1

University Talent Platform · Luglio 2026

> **Novità della v1.1:** il logo primario ha ora due frecce ad arco che racchiudono il wordmark.
> Il wordmark, la M custom, la palette e tutto il design system restano invariati rispetto alla v1.0.

---

## Cosa cambia rispetto alla v1.0

### Il logo ha le frecce

Il lockup primario è ora **wordmark MIRA racchiuso da due frecce ad arco**: quella superiore va da sinistra a destra, quella inferiore da destra a sinistra. Formano una lente attorno al nome e comunicano la circolazione a due sensi tra studenti e aziende — che è esattamente il posizionamento del prodotto: *non mandi CV, sono le aziende a scrivere a te*.

Le frecce fanno parte del logo primario e vanno usate ovunque ci sia spazio: header marketing, footer, documenti, presentazioni, OG image, materiali stampati.

### Dove NON si usano le frecce

- **Sotto i 120px di larghezza** — a quelle dimensioni gli archi diventano illeggibili e sporcano. Usare `mira-wordmark.svg` (solo lettere) o il monogramma.
- **App icon e favicon** — restano con la sola M. Un'icona da 16px con le frecce è illeggibile, e la coerenza tra le dimensioni delle icone conta più della ricchezza del segno.
- **Avatar molto piccoli** — usare il monogramma.

### File nuovi in questa versione

- `mira-emblem.svg` / `mira-emblem-knockout.svg` — la M con le stesse frecce, formato quadrato. Pensato per avatar social e profili (LinkedIn, Instagram, TikTok), dove serve un segno quadrato più ricco del solo monogramma ma più compatto del lockup. **Opzionale**: se non convince, usare il monogramma e ignorare questi file.
- `mira-wordmark.svg` / `mira-wordmark-knockout.svg` — solo le lettere, senza frecce. È il vecchio lockup v1.0, mantenuto per gli spazi stretti (header app compatti, firme email, watermark).
- `og-image.png` — 1200×630 pronta per Open Graph, lockup su cream con tagline.

---

## Cosa c'è dentro

### Documentazione
- `MIRA-brand-manual.pdf` — brand manual v1.0 (le pagine sul logo mostrano ancora la versione senza frecce; da rigenerare quando serve materiale esterno)
- `DESIGN.md` — design system per lo sviluppo (token, componenti, Tailwind config, accessibilità)
- `README.md` — questo file

### Logo SVG (vettoriale)
- `mira-lockup.svg` — **primario**, con frecce, navy su trasparente
- `mira-lockup-cream.svg` — primario con frecce, navy su cream (marketing, letterhead)
- `mira-lockup-knockout.svg` — primario con frecce, bianco su navy
- `mira-wordmark.svg` — solo lettere, senza frecce, navy (spazi stretti)
- `mira-wordmark-knockout.svg` — solo lettere, bianco
- `mira-emblem.svg` — M + frecce, quadrato, navy (avatar social)
- `mira-emblem-knockout.svg` — M + frecce, bianco su navy rounded square
- `mira-monogram.svg` — solo M, navy
- `mira-app-icon.svg` — app icon, M bianca su rounded square navy

### Logo PNG
- `mira-lockup-2400.png`, `mira-lockup-1200.png` — lockup con frecce, trasparente
- `mira-lockup-cream-2400.png` — su fondo cream
- `mira-lockup-knockout-2400.png` — knockout
- `mira-emblem-1024.png`, `mira-emblem-512.png`, `mira-emblem-knockout-1024.png`
- `mira-monogram-1024.png`, `mira-monogram-512.png`
- `mira-app-icon-1024.png` (App Store), `mira-app-icon-512.png` (Play), `mira-app-icon-180.png` (iOS)
- `mira-favicon-32.png`, `mira-favicon-16.png`
- `og-image.png` — 1200×630 per social preview

---

## Regole d'uso delle frecce

**Spazio di rispetto.** Attorno al lockup, lasciare almeno l'altezza della M su tutti i lati. Le frecce fanno già parte dell'ingombro: non calcolare lo spazio dal bordo delle lettere ma dal bordo delle frecce.

**Non separare.** Le frecce non si usano da sole come elemento grafico, e non si usano attorno ad altro testo che non sia il wordmark MIRA.

**Non ricolorare in modo differenziato.** Frecce e lettere hanno sempre lo stesso colore. Mai frecce petrol e lettere navy — è la stessa regola che vale per il wordmark.

**Non animare in loop.** Un'animazione di ingresso sobria (le frecce che si disegnano una volta, 400-600ms) è accettabile su hero e splash. Una rotazione continua o un loop infinito no: diventa un'icona di caricamento.

**Non modificare la geometria.** Curvatura, spessore e dimensione delle punte sono fissi. Se serve una variante, si rigenera dal sorgente, non si stira il file.

---

## Note dalla v1.0 (ancora valide)

### Sulla tipografia
Il wordmark IRA è renderizzato con **Playfair Display** convertito in path — provvisorio in attesa della licenza per **Tiempos Display** (Klim) o **GT Sectra** (Grilli). Quando si passa al carattere definitivo, rigenerare gli SVG mantenendo le proporzioni della M custom e la geometria delle frecce.

Per UI e testi lunghi, **Inter**.

### Sulla M custom
Il monogramma M è completamente originale, non viene da nessun font. Resta l'asset più proprietario del sistema per i formati piccoli.

### Sui colori
Quattro colori, ruoli precisi. Il petrol teal `#0E5A6F` è l'unico accent, usato con parsimonia. Mai il teal sul wordmark o sulle frecce.

---

## Versioning

**v1.1** · Luglio 2026 · Aggiunte le frecce di circolazione al lockup; nuovi emblem e wordmark-only.
**v1.0** · Aprile 2026 · Setup iniziale post-brand-lock.

Gli aggiornamenti futuri vanno in cartelle `v1.2/`, `v2.0/`, mantenendo accessibile la versione precedente.
